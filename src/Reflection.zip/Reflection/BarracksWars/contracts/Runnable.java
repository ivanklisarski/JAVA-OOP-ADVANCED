package Reflection.BarracksWars.contracts;

public interface Runnable {
	void run();
}
