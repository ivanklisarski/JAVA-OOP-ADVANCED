package Reflection.BarracksWars.contracts;

public interface Unit extends Destroyable, Attacker {
}
