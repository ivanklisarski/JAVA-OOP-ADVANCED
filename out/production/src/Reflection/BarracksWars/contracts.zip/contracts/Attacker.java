package Reflection.BarracksWars.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
