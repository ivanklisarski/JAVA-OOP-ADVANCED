package IteratorsNComparators.LinkedListTraversel;

public interface LinkedListTraversal<T> {

    void add(T t);

    boolean remove(T t);

    int getSize();


}
