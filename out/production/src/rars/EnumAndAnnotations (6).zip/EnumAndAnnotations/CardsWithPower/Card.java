package EnumAndAnnotations.CardsWithPower;

public class Card implements Comparable<Card>  {
    private CardRank cardRank;
    private CardSuit cardSuits;

    public Card(String rank, String suit) {
        this.setCardRank(rank);
        this.setCardSuits(suit);
    }

    private void setCardRank(String cardRank) {
        this.cardRank = Enum.valueOf(CardRank.class, cardRank.toUpperCase());
    }

    private void setCardSuits(String cardSuits) {
        this.cardSuits = Enum.valueOf(CardSuit.class, cardSuits.toUpperCase());
    }

    public CardRank getCardRank() {
        return this.cardRank;
    }

    public CardSuit getCardSuits() {
        return this.cardSuits;
    }

    public int getPower() {
        return this.getCardRank().getPower() + this.getCardSuits().getPower();
    }

    @Override
    public String toString() {
        return String.format("%s of %s",
                this.getCardRank().name(),
                this.getCardSuits().name());
    }

    @Override
    public int compareTo(Card o) {
        return Integer.compare(this.getPower(), o.getPower());

    }
}
